import pyautogui
import sys
import random
import time
print('Aperte Ctrl-C para sair.')
try:
    while True:
        x, y = pyautogui.position()
        positionStr = 'X: ' + str(x).rjust(4) + ' Y: ' + str(y).rjust(4)
        print(positionStr, end='')
        print('\b' * len(positionStr), end='', flush=True)
        #! Àrea da tela onde o ponteiro do mosue vai percorrer. Esse valor seta uma área específica onde o ponteiro pode ir, mas pode ser a tela toda também, é só especificar.


except KeyboardInterrupt:
    print('\n')

    